import java.io.File; 
import java.util.Scanner;; 
public class FCFS{ 
    public static void main(String[] args)throws Exception{ 
        
        File file = new File("FCFS.txt"); 
        
        Scanner sc = new Scanner(file); 
        
        int n=sc.nextInt();
        int[][] arr=new int[n][8];
        
        for(int i=0; i<n; i++){
            arr[i][0]=i;
            arr[i][1]=sc.nextInt();   //AT
            arr[i][2]=sc.nextInt();   //BT
        }
        
        for(int i=0; i<n-1; i++){
            for(int j=i+1; j<n; j++){
                if(arr[i][1]>arr[j][1]){
                    int t0=arr[i][0];
                    int t1=arr[i][1];
                    int t2=arr[i][2];
                    arr[i][0]=arr[j][0];
                    arr[i][1]=arr[j][1];
                    arr[i][2]=arr[j][2];
                    arr[j][0]=t0;
                    arr[j][1]=t1;
                    arr[j][2]=t2;
                }
            }
        }
        int idl=0;
        int total=0;
        int c=0;
        
        while(arr[n-1][4]==0){
            if(total>=arr[c][1]){
                arr[c][3]=total;   //FT
                total+=arr[c][2];
                arr[c][4]=total;   //ET
                
                c++;
            }
            else{
                total++;
                idl++;
            }
        }
        
        for(int i=0; i<n; i++){
            arr[i][5]=arr[i][4]-arr[i][1];
            
            arr[i][6]=arr[i][5]-arr[i][2];  
            arr[i][7]=arr[i][3]-arr[i][1];    
        }
        

        double aTat=0;
        double aWT=0;
        double aRT=0;
        
        for(int i=0; i<n; i++){
            aTat+=(double)arr[i][5];
            aWT+=(double)arr[i][6];
            aRT+=(double)arr[i][7];
        }
        
        double x= (double) n/(total-idl);
        System.out.println("Throughput= "+x);
        //System.out.println("Avg TAT= "+(aTat));
        System.out.println("Avg TAT= "+(aTat/n));
        System.out.println("Avg WT= "+(aWT/n));
        System.out.println("Avg RT= "+(aRT/n));
    }
}
                           