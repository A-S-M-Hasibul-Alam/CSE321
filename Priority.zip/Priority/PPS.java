import java.io.File; 
import java.util.Scanner;; 
public class PPS{ 
    public static void main(String[] args)throws Exception{ 
        
        File file = new File("Priority Input.txt"); 
        
        Scanner sc = new Scanner(file); 
        
        int n=sc.nextInt();
        int[][] a=new int[n][11];
        
        for(int i=0; i<n; i++){
            a[i][0]=i;
            a[i][1]=sc.nextInt();   
            a[i][2]=sc.nextInt();
            a[i][9]=a[i][2];
            a[i][3]=sc.nextInt();
        }
        
     
        int idl=0;
        int total=0;
        int c=0;
        int w=0;
        int ie=0;
        while(w==0){
            int min=00;
            for(int i=0; i<n; i++){
                if(min<a[i][3] && a[i][1]<=total && a[i][9]!=0){
                    min=a[i][3];
                     c=i;
                }
            }
            if(total>=a[c][1] && a[c][9]!=0){
                if(a[c][10]==1){
                    total++;
                    a[c][9]--;
                }
                else{
                  a[c][4]=total;   
                  total++;
                  a[c][10]=1;
                  a[c][9]--;
                }
                            
                if(a[c][9]==0){
                  a[c][5]=total;
                }
                
                
                            
            }
            else{
                total++;
                idl++;
            }
            w=1;
            for(int i=0; i<n; i++){
                if(a[i][9]!=0){
                    w=0;
                }
            }

        }
       

       
        for(int i=0; i<n; i++){
            a[i][6]=a[i][5]-a[i][1];
            
            a[i][7]=a[i][6]-a[i][2];  
            a[i][8]=a[i][4]-a[i][1];    
        }
        

        double aTat=0;
        double aWT=0;
        double aRT=0;
        
        for(int i=0; i<n; i++){
            aTat+=(double)a[i][6];
            aWT+=(double)a[i][7];
            aRT+=(double)a[i][8]; 
        }
        
        double x= (double) n/(total-idl);
        System.out.println("Throughput= "+x);
        System.out.println("Avg TAT= "+(aTat/n));
        System.out.println("Avg WT= "+(aWT/n));  
    }
}