import java.io.File; 
import java.util.Scanner;; 
public class SJF{ 
    public static void main(String[] args)throws Exception{ 
        
        File file = new File("ShortestJobFirst Input.txt"); 
        
        Scanner sc = new Scanner(file); 
        
        int n=sc.nextInt();
        int[][] a=new int[n][9];
        
        for(int i=0; i<n; i++){
            a[i][0]=i;
            a[i][1]=sc.nextInt();   //Arrival Time
            a[i][2]=sc.nextInt();   //Burst Time
        }
        
        int idl=0;
        int total=0;
        int c=0;
        int w=0;
        int ie=0;
        while(w==0){
            int min=99;
            for(int i=0; i<n; i++){
                if(min>a[i][2] && a[i][1]<=total && a[i][8]==0){
                    min=a[i][2];
                    c=i;
                    System.out.println(i+" "+min);
                }
            }
            if(total>=a[c][1] && a[c][8]==0){
                a[c][3]=total;   
                total+=a[c][2];
                a[c][4]=total;
                a[c][8]=1;
                
                System.out.println(idl+" "+total+ " "+c);
                
            }
            else{
                total++;
                idl++;
            }
            w=1;
            for(int i=0; i<n; i++){
                if(a[i][8]==0){
                    w=0;
                }
            }
        }
       
        
       
        for(int i=0; i<n; i++){
            a[i][5]=a[i][4]-a[i][1];
            
            a[i][6]=a[i][5]-a[i][2];  
            a[i][7]=a[i][3]-a[i][1];    
        }
        

        double aTat=0;
        double aWT=0;
        double aRT=0;
        
        for(int i=0; i<n; i++){
            aTat+=(double)a[i][5];
            aWT+=(double)a[i][6];
            aRT+=(double)a[i][7]; 
        }
        
        double x= (double) n/(total-idl);
        System.out.println("Throughput= "+x);
        System.out.println("Avg TAT= "+(aTat/n));
        System.out.println("Avg WT= "+(aWT/n));
        System.out.println("Avg RT= "+(aRT/n));         
    }
}