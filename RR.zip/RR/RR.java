import java.io.File; 
import java.util.Scanner;
import java.util.LinkedList; 
import java.util.Queue;

public class RR{ 
    public static void main(String[] args)throws Exception{ 
        Queue<Integer> q = new LinkedList<>();
        File file = new File("RoundRobin Input.txt"); 
        
        Scanner sc = new Scanner(file); 
        
        int n=sc.nextInt();
        int[][] a=new int[n][11];
        int t=sc.nextInt();
        for(int i=0; i<n; i++){
            a[i][0]=i;
            
            a[i][1]=sc.nextInt(); 
            a[i][2]=sc.nextInt(); 
            a[i][9]=a[i][2];
        }
        
     for(int i=0; i<n-1; i++){
            for(int j=i+1; j<n; j++){
                if(a[i][1]>a[j][1]){
                    int t0=a[i][0];
                    int t1=a[i][1];
                    int t2=a[i][2];
                    a[i][0]=a[j][0];
                    a[i][1]=a[j][1];
                    a[i][2]=a[j][2];
                    a[j][0]=t0;
                    a[j][1]=t1;
                    a[j][2]=t2;
                }
                
            }
        }
        int idl=0;
        int total=0;
        int c=99;
        int w=0;
        int ie=0;
        boolean flag=false;
        for(int i=0; i<n; i++){
                if(total>=a[i][1] && a[i][9]!=0){
                    q.add(a[i][0]);
                    a[i][10]=1;
                }
         }
        
        
        
        while(w==0){
            
            
            
            if(q.size()!=0){
                flag=true;
                c=q.peek();
                q.remove();
                if(t<a[c][9]){
                    a[c][9]-=t;
                    if(a[c][8]==0){
                        a[c][3]=total;
                        total+=t;
                        a[c][8]=1;
                    }
                    else{
                        total+=t;
                    }
                    
                }
                else{
                    if(a[c][8]==0){
                        a[c][3]=total;
                        total+=a[c][9];
                        a[c][4]=total;
                        a[c][8]=1;
                        a[c][9]=0;
                    }
                    else{
                        total+=a[c][9];
                        a[c][4]=total;
                        a[c][9]=0;
                    }
                }
            }
            else{
                total++;
                idl++;
            }
            for(int i=0; i<n; i++){
                if(total>=a[i][1] && a[i][9]!=0 && a[i][10]!=1){
                    q.add(a[i][0]);
                    a[i][10]=1;
                }
            }
            if(q.size()!=0 && flag && a[c][9]!=0){
                q.add(c);
            }
            w=1;
            for(int i=0; i<n; i++){
                if(a[i][9]!=0){
                    w=0;
                }
            }
        }
       
        
       
        for(int i=0; i<n; i++){
            a[i][5]=a[i][4]-a[i][1];
            a[i][6]=a[i][5]-a[i][2];  
            a[i][7]=a[i][3]-a[i][1];    
        }
        

        double aTat=0;
        double aWT=0;
        double aRT=0;
        
        for(int i=0; i<n; i++){
            aTat+=(double)a[i][5];
            aWT+=(double)a[i][6];
            aRT+=(double)a[i][7]; 
        }
        
        double x= (double) n/(total-idl);
        System.out.println("Throughput= "+x);
        System.out.println("Avg TAT= "+(aTat/n));
        System.out.println("Avg WT= "+(aWT/n));
        System.out.println("Avg RT= "+(aRT/n));         
    }
}